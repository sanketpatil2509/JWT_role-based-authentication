﻿namespace JWT_Authentication.Models
{
    public class Form
    {
        public int Id { get; set; }
        public string FormName { get; set; }
        public int CanRead { get; set; }
        public int CanCreate { get; set; }
        public int CanUpdate { get; set; }
        public int CanDelete { get; set; }
    }
}

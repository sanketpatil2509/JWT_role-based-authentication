﻿namespace JWT_Authentication.Models
{
    public class AddRolePermission
    {
        public int RoleId { get; set; }
        public List<int> FormIds { get; set; }
        //public int CanRead { get; set; }
        //public int CanCreate { get; set; }
        //public int CanUpdate { get; set; }
        //public int CanDelete { get; set; }
    }
}

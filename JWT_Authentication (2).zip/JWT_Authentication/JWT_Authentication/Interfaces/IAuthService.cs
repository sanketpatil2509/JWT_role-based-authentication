﻿using JWT_Authentication.Models;
using Microsoft.AspNetCore.Identity.Data;

namespace JWT_Authentication.Interfaces
{
    public interface IAuthService
    {
        User AddUser(User user);

        //string Login(LoginRequest loginRequest);

        Role AddRole(Role role);
        bool AssignRoleToUser(AddUserRole obj);
        string Login(Models.LoginRequest obj);
        Form AddForm(Form form);
        bool AssignRoleToRolePermission(AddRolePermission obj);


    }
}
